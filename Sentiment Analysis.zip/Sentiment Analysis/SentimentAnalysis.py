{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 2,
   "metadata": {},
   "outputs": [],
   "source": [
    "import pandas as pd\n",
    "import numpy as np\n",
    "import string \n",
    "import nltk\n",
    "from nltk.corpus import stopwords\n",
    "from nltk.tokenize import word_tokenize\n",
    "import matplotlib.pyplot as plt"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 3,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>id</th>\n",
       "      <th>dateAdded</th>\n",
       "      <th>dateUpdated</th>\n",
       "      <th>name</th>\n",
       "      <th>asins</th>\n",
       "      <th>brand</th>\n",
       "      <th>categories</th>\n",
       "      <th>primaryCategories</th>\n",
       "      <th>imageURLs</th>\n",
       "      <th>keys</th>\n",
       "      <th>...</th>\n",
       "      <th>reviews.didPurchase</th>\n",
       "      <th>reviews.doRecommend</th>\n",
       "      <th>reviews.id</th>\n",
       "      <th>reviews.numHelpful</th>\n",
       "      <th>reviews.rating</th>\n",
       "      <th>reviews.sourceURLs</th>\n",
       "      <th>reviews.text</th>\n",
       "      <th>reviews.title</th>\n",
       "      <th>reviews.username</th>\n",
       "      <th>sourceURLs</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>0</th>\n",
       "      <td>AVpgNzjwLJeJML43Kpxn</td>\n",
       "      <td>2015-10-30T08:59:32Z</td>\n",
       "      <td>2019-04-25T09:08:16Z</td>\n",
       "      <td>AmazonBasics AAA Performance Alkaline Batterie...</td>\n",
       "      <td>B00QWO9P0O,B00LH3DMUO</td>\n",
       "      <td>Amazonbasics</td>\n",
       "      <td>AA,AAA,Health,Electronics,Health &amp; Household,C...</td>\n",
       "      <td>Health &amp; Beauty</td>\n",
       "      <td>https://images-na.ssl-images-amazon.com/images...</td>\n",
       "      <td>amazonbasics/hl002619,amazonbasicsaaaperforman...</td>\n",
       "      <td>...</td>\n",
       "      <td>NaN</td>\n",
       "      <td>NaN</td>\n",
       "      <td>NaN</td>\n",
       "      <td>NaN</td>\n",
       "      <td>3</td>\n",
       "      <td>https://www.amazon.com/product-reviews/B00QWO9...</td>\n",
       "      <td>I order 3 of them and one of the item is bad q...</td>\n",
       "      <td>... 3 of them and one of the item is bad quali...</td>\n",
       "      <td>Byger yang</td>\n",
       "      <td>https://www.barcodable.com/upc/841710106442,ht...</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1</th>\n",
       "      <td>AVpgNzjwLJeJML43Kpxn</td>\n",
       "      <td>2015-10-30T08:59:32Z</td>\n",
       "      <td>2019-04-25T09:08:16Z</td>\n",
       "      <td>AmazonBasics AAA Performance Alkaline Batterie...</td>\n",
       "      <td>B00QWO9P0O,B00LH3DMUO</td>\n",
       "      <td>Amazonbasics</td>\n",
       "      <td>AA,AAA,Health,Electronics,Health &amp; Household,C...</td>\n",
       "      <td>Health &amp; Beauty</td>\n",
       "      <td>https://images-na.ssl-images-amazon.com/images...</td>\n",
       "      <td>amazonbasics/hl002619,amazonbasicsaaaperforman...</td>\n",
       "      <td>...</td>\n",
       "      <td>NaN</td>\n",
       "      <td>NaN</td>\n",
       "      <td>NaN</td>\n",
       "      <td>NaN</td>\n",
       "      <td>4</td>\n",
       "      <td>https://www.amazon.com/product-reviews/B00QWO9...</td>\n",
       "      <td>Bulk is always the less expensive way to go fo...</td>\n",
       "      <td>... always the less expensive way to go for pr...</td>\n",
       "      <td>ByMG</td>\n",
       "      <td>https://www.barcodable.com/upc/841710106442,ht...</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2</th>\n",
       "      <td>AVpgNzjwLJeJML43Kpxn</td>\n",
       "      <td>2015-10-30T08:59:32Z</td>\n",
       "      <td>2019-04-25T09:08:16Z</td>\n",
       "      <td>AmazonBasics AAA Performance Alkaline Batterie...</td>\n",
       "      <td>B00QWO9P0O,B00LH3DMUO</td>\n",
       "      <td>Amazonbasics</td>\n",
       "      <td>AA,AAA,Health,Electronics,Health &amp; Household,C...</td>\n",
       "      <td>Health &amp; Beauty</td>\n",
       "      <td>https://images-na.ssl-images-amazon.com/images...</td>\n",
       "      <td>amazonbasics/hl002619,amazonbasicsaaaperforman...</td>\n",
       "      <td>...</td>\n",
       "      <td>NaN</td>\n",
       "      <td>NaN</td>\n",
       "      <td>NaN</td>\n",
       "      <td>NaN</td>\n",
       "      <td>5</td>\n",
       "      <td>https://www.amazon.com/product-reviews/B00QWO9...</td>\n",
       "      <td>Well they are not Duracell but for the price i...</td>\n",
       "      <td>... are not Duracell but for the price i am ha...</td>\n",
       "      <td>BySharon Lambert</td>\n",
       "      <td>https://www.barcodable.com/upc/841710106442,ht...</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3</th>\n",
       "      <td>AVpgNzjwLJeJML43Kpxn</td>\n",
       "      <td>2015-10-30T08:59:32Z</td>\n",
       "      <td>2019-04-25T09:08:16Z</td>\n",
       "      <td>AmazonBasics AAA Performance Alkaline Batterie...</td>\n",
       "      <td>B00QWO9P0O,B00LH3DMUO</td>\n",
       "      <td>Amazonbasics</td>\n",
       "      <td>AA,AAA,Health,Electronics,Health &amp; Household,C...</td>\n",
       "      <td>Health &amp; Beauty</td>\n",
       "      <td>https://images-na.ssl-images-amazon.com/images...</td>\n",
       "      <td>amazonbasics/hl002619,amazonbasicsaaaperforman...</td>\n",
       "      <td>...</td>\n",
       "      <td>NaN</td>\n",
       "      <td>NaN</td>\n",
       "      <td>NaN</td>\n",
       "      <td>NaN</td>\n",
       "      <td>5</td>\n",
       "      <td>https://www.amazon.com/product-reviews/B00QWO9...</td>\n",
       "      <td>Seem to work as well as name brand batteries a...</td>\n",
       "      <td>... as well as name brand batteries at a much ...</td>\n",
       "      <td>Bymark sexson</td>\n",
       "      <td>https://www.barcodable.com/upc/841710106442,ht...</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>4</th>\n",
       "      <td>AVpgNzjwLJeJML43Kpxn</td>\n",
       "      <td>2015-10-30T08:59:32Z</td>\n",
       "      <td>2019-04-25T09:08:16Z</td>\n",
       "      <td>AmazonBasics AAA Performance Alkaline Batterie...</td>\n",
       "      <td>B00QWO9P0O,B00LH3DMUO</td>\n",
       "      <td>Amazonbasics</td>\n",
       "      <td>AA,AAA,Health,Electronics,Health &amp; Household,C...</td>\n",
       "      <td>Health &amp; Beauty</td>\n",
       "      <td>https://images-na.ssl-images-amazon.com/images...</td>\n",
       "      <td>amazonbasics/hl002619,amazonbasicsaaaperforman...</td>\n",
       "      <td>...</td>\n",
       "      <td>NaN</td>\n",
       "      <td>NaN</td>\n",
       "      <td>NaN</td>\n",
       "      <td>NaN</td>\n",
       "      <td>5</td>\n",
       "      <td>https://www.amazon.com/product-reviews/B00QWO9...</td>\n",
       "      <td>These batteries are very long lasting the pric...</td>\n",
       "      <td>... batteries are very long lasting the price ...</td>\n",
       "      <td>Bylinda</td>\n",
       "      <td>https://www.barcodable.com/upc/841710106442,ht...</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "<p>5 rows × 24 columns</p>\n",
       "</div>"
      ],
      "text/plain": [
       "                     id             dateAdded           dateUpdated  \\\n",
       "0  AVpgNzjwLJeJML43Kpxn  2015-10-30T08:59:32Z  2019-04-25T09:08:16Z   \n",
       "1  AVpgNzjwLJeJML43Kpxn  2015-10-30T08:59:32Z  2019-04-25T09:08:16Z   \n",
       "2  AVpgNzjwLJeJML43Kpxn  2015-10-30T08:59:32Z  2019-04-25T09:08:16Z   \n",
       "3  AVpgNzjwLJeJML43Kpxn  2015-10-30T08:59:32Z  2019-04-25T09:08:16Z   \n",
       "4  AVpgNzjwLJeJML43Kpxn  2015-10-30T08:59:32Z  2019-04-25T09:08:16Z   \n",
       "\n",
       "                                                name                  asins  \\\n",
       "0  AmazonBasics AAA Performance Alkaline Batterie...  B00QWO9P0O,B00LH3DMUO   \n",
       "1  AmazonBasics AAA Performance Alkaline Batterie...  B00QWO9P0O,B00LH3DMUO   \n",
       "2  AmazonBasics AAA Performance Alkaline Batterie...  B00QWO9P0O,B00LH3DMUO   \n",
       "3  AmazonBasics AAA Performance Alkaline Batterie...  B00QWO9P0O,B00LH3DMUO   \n",
       "4  AmazonBasics AAA Performance Alkaline Batterie...  B00QWO9P0O,B00LH3DMUO   \n",
       "\n",
       "          brand                                         categories  \\\n",
       "0  Amazonbasics  AA,AAA,Health,Electronics,Health & Household,C...   \n",
       "1  Amazonbasics  AA,AAA,Health,Electronics,Health & Household,C...   \n",
       "2  Amazonbasics  AA,AAA,Health,Electronics,Health & Household,C...   \n",
       "3  Amazonbasics  AA,AAA,Health,Electronics,Health & Household,C...   \n",
       "4  Amazonbasics  AA,AAA,Health,Electronics,Health & Household,C...   \n",
       "\n",
       "  primaryCategories                                          imageURLs  \\\n",
       "0   Health & Beauty  https://images-na.ssl-images-amazon.com/images...   \n",
       "1   Health & Beauty  https://images-na.ssl-images-amazon.com/images...   \n",
       "2   Health & Beauty  https://images-na.ssl-images-amazon.com/images...   \n",
       "3   Health & Beauty  https://images-na.ssl-images-amazon.com/images...   \n",
       "4   Health & Beauty  https://images-na.ssl-images-amazon.com/images...   \n",
       "\n",
       "                                                keys  ... reviews.didPurchase  \\\n",
       "0  amazonbasics/hl002619,amazonbasicsaaaperforman...  ...                 NaN   \n",
       "1  amazonbasics/hl002619,amazonbasicsaaaperforman...  ...                 NaN   \n",
       "2  amazonbasics/hl002619,amazonbasicsaaaperforman...  ...                 NaN   \n",
       "3  amazonbasics/hl002619,amazonbasicsaaaperforman...  ...                 NaN   \n",
       "4  amazonbasics/hl002619,amazonbasicsaaaperforman...  ...                 NaN   \n",
       "\n",
       "  reviews.doRecommend reviews.id reviews.numHelpful reviews.rating  \\\n",
       "0                 NaN        NaN                NaN              3   \n",
       "1                 NaN        NaN                NaN              4   \n",
       "2                 NaN        NaN                NaN              5   \n",
       "3                 NaN        NaN                NaN              5   \n",
       "4                 NaN        NaN                NaN              5   \n",
       "\n",
       "                                  reviews.sourceURLs  \\\n",
       "0  https://www.amazon.com/product-reviews/B00QWO9...   \n",
       "1  https://www.amazon.com/product-reviews/B00QWO9...   \n",
       "2  https://www.amazon.com/product-reviews/B00QWO9...   \n",
       "3  https://www.amazon.com/product-reviews/B00QWO9...   \n",
       "4  https://www.amazon.com/product-reviews/B00QWO9...   \n",
       "\n",
       "                                        reviews.text  \\\n",
       "0  I order 3 of them and one of the item is bad q...   \n",
       "1  Bulk is always the less expensive way to go fo...   \n",
       "2  Well they are not Duracell but for the price i...   \n",
       "3  Seem to work as well as name brand batteries a...   \n",
       "4  These batteries are very long lasting the pric...   \n",
       "\n",
       "                                       reviews.title  reviews.username  \\\n",
       "0  ... 3 of them and one of the item is bad quali...        Byger yang   \n",
       "1  ... always the less expensive way to go for pr...              ByMG   \n",
       "2  ... are not Duracell but for the price i am ha...  BySharon Lambert   \n",
       "3  ... as well as name brand batteries at a much ...     Bymark sexson   \n",
       "4  ... batteries are very long lasting the price ...           Bylinda   \n",
       "\n",
       "                                          sourceURLs  \n",
       "0  https://www.barcodable.com/upc/841710106442,ht...  \n",
       "1  https://www.barcodable.com/upc/841710106442,ht...  \n",
       "2  https://www.barcodable.com/upc/841710106442,ht...  \n",
       "3  https://www.barcodable.com/upc/841710106442,ht...  \n",
       "4  https://www.barcodable.com/upc/841710106442,ht...  \n",
       "\n",
       "[5 rows x 24 columns]"
      ]
     },
     "execution_count": 3,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "df=pd.read_csv(r\"C:\\Users\\Aman Chauhan\\Desktop\\data.csv\")\n",
    "df.head()"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "**DATA TYPES**"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 42,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "id                      object\n",
       "dateAdded               object\n",
       "dateUpdated             object\n",
       "name                    object\n",
       "asins                   object\n",
       "brand                   object\n",
       "categories              object\n",
       "primaryCategories       object\n",
       "imageURLs               object\n",
       "keys                    object\n",
       "manufacturer            object\n",
       "manufacturerNumber      object\n",
       "reviews.date            object\n",
       "reviews.dateSeen        object\n",
       "reviews.didPurchase     object\n",
       "reviews.doRecommend     object\n",
       "reviews.id             float64\n",
       "reviews.numHelpful     float64\n",
       "reviews.rating           int64\n",
       "reviews.sourceURLs      object\n",
       "reviews.text            object\n",
       "reviews.title           object\n",
       "reviews.username        object\n",
       "sourceURLs              object\n",
       "dtype: object"
      ]
     },
     "execution_count": 42,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "df.dtypes"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 44,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Table Dimension: (28332, 24)\n",
      "-------------\n",
      "Total Rows: 28332\n",
      "-------------\n",
      "Total Columns: 24\n",
      "-------------\n",
      "columns:\n",
      " ['id' 'dateAdded' 'dateUpdated' 'name' 'asins' 'brand' 'categories'\n",
      " 'primaryCategories' 'imageURLs' 'keys' 'manufacturer'\n",
      " 'manufacturerNumber' 'reviews.date' 'reviews.dateSeen'\n",
      " 'reviews.didPurchase' 'reviews.doRecommend' 'reviews.id'\n",
      " 'reviews.numHelpful' 'reviews.rating' 'reviews.sourceURLs' 'reviews.text'\n",
      " 'reviews.title' 'reviews.username' 'sourceURLs']\n"
     ]
    }
   ],
   "source": [
    "df.shape\n",
    "row=df.shape[0]\n",
    "cols=df.shape[1]\n",
    "print('Table Dimension:',df.shape)\n",
    "print('-------------')\n",
    "print('Total Rows:',row)\n",
    "print('-------------')\n",
    "print('Total Columns:',cols)\n",
    "print('-------------')\n",
    "print('columns:\\n',df.columns.values)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 45,
   "metadata": {
    "scrolled": true
   },
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Data Overview\n",
      "\n",
      "<class 'pandas.core.frame.DataFrame'>\n",
      "RangeIndex: 28332 entries, 0 to 28331\n",
      "Data columns (total 3 columns):\n",
      " #   Column          Non-Null Count  Dtype \n",
      "---  ------          --------------  ----- \n",
      " 0   reviews.rating  28332 non-null  int64 \n",
      " 1   reviews.text    28332 non-null  object\n",
      " 2   reviews.title   28332 non-null  object\n",
      "dtypes: int64(1), object(2)\n",
      "memory usage: 664.2+ KB\n",
      "None\n"
     ]
    }
   ],
   "source": [
    "print(\"Data Overview\\n\")\n",
    "print(data.info())"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 81,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "reviews.numHelpful   -0.041006\n",
       "reviews.id            0.074941\n",
       "reviews.rating        1.000000\n",
       "Name: reviews.rating, dtype: float64"
      ]
     },
     "execution_count": 81,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "#uses the Pandas method corr() to find the feature other than rating that is most correlated with rating.\n",
    "df.corr()['reviews.rating'].sort_values()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 25,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "0    3\n",
       "1    4\n",
       "2    5\n",
       "3    5\n",
       "4    5\n",
       "Name: reviews.rating, dtype: int64"
      ]
     },
     "execution_count": 25,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "df['reviews.rating'].head()"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "**NORMALIZATION** (Replaceing NaN value with mean value)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 16,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "\n",
      "Mean of Rating Review: 4.514047719892701\n"
     ]
    }
   ],
   "source": [
    "mean=df[\"reviews.rating\"].mean()\n",
    "print(\"\\nMean of Rating Review:\",mean)\n",
    "df['reviews.rating'].replace(np.nan,mean,inplace=True)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 39,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Total NaN Values:\n",
      "\n"
     ]
    },
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>0</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>reviews.rating</th>\n",
       "      <td>0</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>reviews.text</th>\n",
       "      <td>0</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>reviews.title</th>\n",
       "      <td>0</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "                0\n",
       "reviews.rating  0\n",
       "reviews.text    0\n",
       "reviews.title   0"
      ]
     },
     "execution_count": 39,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "print(\"Total NaN Values:\\n\")\n",
    "data.isna().sum().to_frame()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 40,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Total Null Values: \n",
      "\n"
     ]
    },
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>0</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>reviews.rating</th>\n",
       "      <td>0</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>reviews.text</th>\n",
       "      <td>0</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>reviews.title</th>\n",
       "      <td>0</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "                0\n",
       "reviews.rating  0\n",
       "reviews.text    0\n",
       "reviews.title   0"
      ]
     },
     "execution_count": 40,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "print(\"Total Null Values: \\n\")\n",
    "data.isnull().sum().to_frame()"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "**ATTRIBUTES USED FOR SENTIMENT ANALYSIS**"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 8,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Explore Filtered Data:\n"
     ]
    },
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>reviews.rating</th>\n",
       "      <th>reviews.text</th>\n",
       "      <th>reviews.title</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>0</th>\n",
       "      <td>3</td>\n",
       "      <td>I order 3 of them and one of the item is bad q...</td>\n",
       "      <td>... 3 of them and one of the item is bad quali...</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1</th>\n",
       "      <td>4</td>\n",
       "      <td>Bulk is always the less expensive way to go fo...</td>\n",
       "      <td>... always the less expensive way to go for pr...</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2</th>\n",
       "      <td>5</td>\n",
       "      <td>Well they are not Duracell but for the price i...</td>\n",
       "      <td>... are not Duracell but for the price i am ha...</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3</th>\n",
       "      <td>5</td>\n",
       "      <td>Seem to work as well as name brand batteries a...</td>\n",
       "      <td>... as well as name brand batteries at a much ...</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>4</th>\n",
       "      <td>5</td>\n",
       "      <td>These batteries are very long lasting the pric...</td>\n",
       "      <td>... batteries are very long lasting the price ...</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "   reviews.rating                                       reviews.text  \\\n",
       "0               3  I order 3 of them and one of the item is bad q...   \n",
       "1               4  Bulk is always the less expensive way to go fo...   \n",
       "2               5  Well they are not Duracell but for the price i...   \n",
       "3               5  Seem to work as well as name brand batteries a...   \n",
       "4               5  These batteries are very long lasting the pric...   \n",
       "\n",
       "                                       reviews.title  \n",
       "0  ... 3 of them and one of the item is bad quali...  \n",
       "1  ... always the less expensive way to go for pr...  \n",
       "2  ... are not Duracell but for the price i am ha...  \n",
       "3  ... as well as name brand batteries at a much ...  \n",
       "4  ... batteries are very long lasting the price ...  "
      ]
     },
     "execution_count": 8,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "data=df[['reviews.rating','reviews.text','reviews.title']]\n",
    "print(\"Explore Filtered Data:\")\n",
    "data.head()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 24,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Explore Descriptive Statistics\n",
      "<class 'pandas.core.frame.DataFrame'>\n",
      "RangeIndex: 28332 entries, 0 to 28331\n",
      "Data columns (total 3 columns):\n",
      " #   Column          Non-Null Count  Dtype \n",
      "---  ------          --------------  ----- \n",
      " 0   reviews.rating  28332 non-null  int64 \n",
      " 1   reviews.text    28332 non-null  object\n",
      " 2   reviews.title   28332 non-null  object\n",
      "dtypes: int64(1), object(2)\n",
      "memory usage: 664.2+ KB\n"
     ]
    }
   ],
   "source": [
    "print(\"Explore Descriptive Statistics\")\n",
    "data.info()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 17,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "(28332, 3)"
      ]
     },
     "execution_count": 17,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "#Dimension Information\n",
    "data.shape"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 18,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>reviews.rating</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>count</th>\n",
       "      <td>28332.000000</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>mean</th>\n",
       "      <td>4.514048</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>std</th>\n",
       "      <td>0.934957</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>min</th>\n",
       "      <td>1.000000</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>25%</th>\n",
       "      <td>4.000000</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>50%</th>\n",
       "      <td>5.000000</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>75%</th>\n",
       "      <td>5.000000</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>max</th>\n",
       "      <td>5.000000</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "       reviews.rating\n",
       "count    28332.000000\n",
       "mean         4.514048\n",
       "std          0.934957\n",
       "min          1.000000\n",
       "25%          4.000000\n",
       "50%          5.000000\n",
       "75%          5.000000\n",
       "max          5.000000"
      ]
     },
     "execution_count": 18,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "#Data Statistics Description\n",
    "data.describe()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 78,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>reviews.rating</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>5</th>\n",
       "      <td>19897</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>4</th>\n",
       "      <td>5648</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3</th>\n",
       "      <td>1206</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1</th>\n",
       "      <td>965</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2</th>\n",
       "      <td>616</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "   reviews.rating\n",
       "5           19897\n",
       "4            5648\n",
       "3            1206\n",
       "1             965\n",
       "2             616"
      ]
     },
     "execution_count": 78,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "data[\"reviews.rating\"].value_counts().to_frame()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 99,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "image/png": "iVBORw0KGgoAAAANSUhEUgAAAYMAAAEWCAYAAACEz/viAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAALEgAACxIB0t1+/AAAADh0RVh0U29mdHdhcmUAbWF0cGxvdGxpYiB2ZXJzaW9uMy4xLjMsIGh0dHA6Ly9tYXRwbG90bGliLm9yZy+AADFEAAAbH0lEQVR4nO3de7hdVX3u8e9LAoqiXEykCNGgpq1I24AR8KhHvDwQ8AK2tuLTSvTgSbUg9S7eCqJUvFuq0qLkEEQFvBW0KEQOFGy5BcSQQJUciBJBCIJyFQV/5485ti531r5mZ+8d8/08z3r2WmPOOeaYcyXzXXPMucZKVSFJ2rxtMdUNkCRNPcNAkmQYSJIMA0kShoEkCcNAkoRhoAmU5F+SvGeC6np8knuSzGivL0zymomou9X3zSSLJqq+Maz3/UluT/KTyV53n7bck+SJU90OTQ+GgUYlyZok9ye5O8nPkvxXktcm+c2/oap6bVW9b5R1vWC4earqR1W1TVU9NAFtPybJaYPqP6Cqlm5o3WNsxxzgzcBuVfUHQ8zzziQ3tgP12iRnTNC61wvTtn9vmIj6x9iWEd9/TT7DQGPx4qp6FPAE4Hjg7cDJE72SJDMnus5p4gnAT6vqtn4T25nKK4EXVNU2wALg/ElsnzZnVeXDx4gPYA3dQaq3bC/g18Du7fUpwPvb81nAN4CfAXcAF9N9+PhcW+Z+4B7gbcBcoIDDgB8BF/WUzWz1XQh8ALgc+DlwFrBDm7YvsLZfe4GFwC+BX7X1fa+nvte051sA7wZ+CNwGnAps26YNtGNRa9vtwLuG2U/btuXXtfre3ep/QdvmX7d2nNJn2U8Cnxih7pOBW4AfA+8HZrRprwK+A3wEuBO4ETigTTsOeAj4RVv3J1t5AU/uee8+DXyzzfOfwB8An2j1/TewR09bHgd8pW3njcCRPdOOAc5s++FuYBWwoE1b7/2f6n/bPrqHZwYat6q6HFgLPLvP5De3abOBHYF3dovUK+kOqi+urpviQz3LPAd4CrD/EKs8FPhfdAeiB4ETRtHGbwH/CJzR1vdnfWZ7VXs8F3gisA3dgbnXs4A/Ap4P/EOSpwyxyn+mO2g/sW3PocCrq+rbwAHAza0dr+qz7KXAoUnemmTBwPWSHkvptvvJwB7AfkBv18/ewPfpgvhDwMlJUlXvogvjI9q6jxii7X9FF16zgAeAS4Cr2usvAx8DaF2DXwe+B+zc9skbkvS+by8BTge2A86m7c8R3n9NIcNAG+pmYIc+5b8CdgKeUFW/qqqLq300HMYxVXVvVd0/xPTPVdXKqroXeA/wV30OmOPx18DHquqGqroHeAdwyKDuqvdW1f1V9T26g+B6odLa8nLgHVV1d1WtAT5K1/Uzoqo6DXg9XRj+B3BbkqNa3TvShckb2j66Dfg4cEhPFT+sqs9Ud51lKd3+33HUewG+VlVXVtUvgK8Bv6iqU1t9Z9AFEMDTgdlVdWxV/bK66w6fGdSW71TVOW3Zz9Fnf2l6+X3tm9Xk2ZmuG2iwD9N1F5yXBOCkqjp+hLpuGsP0HwJb0n1q3VCPa/X11j2T3z2Q9t79cx/d2cNgs4Ct+tS182gbUlWfBz6fZEvg4Pb8u3RdNVsCt7T9Cd2Hud598pOeeu5r8/Vr51Bu7Xl+f5/XA3U9AXhckp/1TJ9Bd/axXlvo9tfDk8ysqgfH0B5NIs8MNG5Jnk53oPvO4Gntk/Gbq+qJwIuBNyV5/sDkIaoc6cxhTs/zx9OdfdwO3As8oqddM+i6p0Zb7810B7jeuh/kdw+Go3F7a9Pgun48xnpoZ1NfAlYAu9Md9B8AZlXVdu3x6Kp66mirHGsbhnETcGNPO7arqkdV1YFT0BZNEMNAY5bk0UleRNcnfFpVXdNnnhcleXK6j6d30V3AHLhN9Fa6PvWx+pskuyV5BHAs8OXWDfEDuk+eL2yfqN8NPKxnuVuBub23wQ7yReCNSXZNsg2/vcYwpk+xrS1nAscleVSSJwBvAk4bfslOkle1bXhUki2SHAA8Fbisqm4BzgM+2vb/FkmelOQ5o2zeePd5P5cDdyV5e5Ktk8xIsnv7cDDZbdEEMQw0Fl9PcjfdJ8N30V1QfPUQ884Dvk13x8glwKer6sI27QPAu9v3Fd4yhvV/ju6ul58ADweOBKiqnwN/B3yW7lP4vXQXrwd8qf39aZKr+tS7pNV9Ed2dMb+g67sfj9e39d9Ad8b0hVb/aNxFd6H9R3R3YX0IeF1VDZx5HUrXDXUtXbfRl+muC4zGPwEvS3JnkhEvvA+nhd6Lgfl0++t2un2/7SirGO/7r40oI1/TkyT9vvPMQJJkGEiSDANJEoaBJIlN+Etns2bNqrlz5051MyRpk3LllVfeXlWzB5dvsmEwd+5cli9fPtXNkKRNSpIf9iu3m0iSZBhIkgwDSRKGgSQJw0CShGEgScIwkCRhGEiSMAwkSWzC30CWtOmYe9S/T3UTfi+tOf6FE1bXiGcGSeYkuSDJdUlWJfn7Vn5Mkh8nubo9DuxZ5h1JVif5fpL9e8oXtrLVSY7qKd81yWVJrk9yRpKtJmwLJUkjGk030YPAm6vqKcA+wOFJdmvTPl5V89vjHIA27RC6325dCHy6/UbqDOBTwAHAbsAreur5YKtrHt3P+R02QdsnSRqFEcOgqm6pqqva87uB64Cdh1nkIOD0qnqgqm4EVgN7tcfqqrqhqn5J92PqB7UfTH8e3e+5AiwFDh7vBkmSxm5MF5CTzAX2AC5rRUckWZFkSZLtW9nOdD+YPmBtKxuq/DHAz6rqwUHl/da/OMnyJMvXrVs3lqZLkoYx6jBIsg3wFeANVXUXcCLwJGA+cAvw0YFZ+yxe4yhfv7DqpKpaUFULZs9ebzhuSdI4jepuoiRb0gXB56vqqwBVdWvP9M8A32gv1wJzehbfBbi5Pe9XfjuwXZKZ7eygd35J0iQYzd1EAU4Grquqj/WU79Qz20uBle352cAhSR6WZFdgHnA5cAUwr905tBXdReazq6qAC4CXteUXAWdt2GZJksZiNGcGzwReCVyT5OpW9k66u4Hm03XprAH+FqCqViU5E7iW7k6kw6vqIYAkRwDnAjOAJVW1qtX3duD0JO8HvksXPpKkSTJiGFTVd+jfr3/OMMscBxzXp/ycfstV1Q10dxtJkqaAw1FIkgwDSZJhIEnCMJAkYRhIkjAMJEkYBpIkDANJEoaBJAnDQJKEYSBJwjCQJGEYSJIwDCRJGAaSJAwDSRKGgSQJw0CShGEgScIwkCRhGEiSMAwkSRgGkiQMA0kShoEkCcNAkoRhIEnCMJAkYRhIkjAMJEkYBpIkDANJEqMIgyRzklyQ5Lokq5L8fSvfIcmyJNe3v9u38iQ5IcnqJCuS7NlT16I2//VJFvWUPy3JNW2ZE5JkY2ysJKm/0ZwZPAi8uaqeAuwDHJ5kN+Ao4Pyqmgec314DHADMa4/FwInQhQdwNLA3sBdw9ECAtHkW9yy3cMM3TZI0WiOGQVXdUlVXted3A9cBOwMHAUvbbEuBg9vzg4BTq3MpsF2SnYD9gWVVdUdV3QksAxa2aY+uqkuqqoBTe+qSJE2CMV0zSDIX2AO4DNixqm6BLjCAx7bZdgZu6llsbSsbrnxtn/J+61+cZHmS5evWrRtL0yVJwxh1GCTZBvgK8Iaqumu4WfuU1TjK1y+sOqmqFlTVgtmzZ4/UZEnSKI0qDJJsSRcEn6+qr7biW1sXD+3vba18LTCnZ/FdgJtHKN+lT7kkaZKM5m6iACcD11XVx3omnQ0M3BG0CDirp/zQdlfRPsDPWzfSucB+SbZvF473A85t0+5Osk9b16E9dUmSJsHMUczzTOCVwDVJrm5l7wSOB85MchjwI+Av27RzgAOB1cB9wKsBquqOJO8DrmjzHVtVd7TnrwNOAbYGvtkekqRJMmIYVNV36N+vD/D8PvMXcPgQdS0BlvQpXw7sPlJbJEkbh99AliQZBpIkw0CShGEgScIwkCRhGEiSMAwkSRgGkiQMA0kShoEkCcNAkoRhIEnCMJAkYRhIkjAMJEkYBpIkDANJEoaBJAnDQJKEYSBJwjCQJGEYSJIwDCRJGAaSJAwDSRKGgSQJw0CShGEgScIwkCRhGEiSMAwkSYwiDJIsSXJbkpU9Zcck+XGSq9vjwJ5p70iyOsn3k+zfU76wla1OclRP+a5JLktyfZIzkmw1kRsoSRrZaM4MTgEW9in/eFXNb49zAJLsBhwCPLUt8+kkM5LMAD4FHADsBryizQvwwVbXPOBO4LAN2SBJ0tiNGAZVdRFwxyjrOwg4vaoeqKobgdXAXu2xuqpuqKpfAqcDByUJ8Dzgy235pcDBY9wGSdIG2pBrBkckWdG6kbZvZTsDN/XMs7aVDVX+GOBnVfXgoPK+kixOsjzJ8nXr1m1A0yVJvcYbBicCTwLmA7cAH23l6TNvjaO8r6o6qaoWVNWC2bNnj63FkqQhzRzPQlV168DzJJ8BvtFergXm9My6C3Bze96v/HZguyQz29lB7/ySpEkyrjODJDv1vHwpMHCn0dnAIUkelmRXYB5wOXAFMK/dObQV3UXms6uqgAuAl7XlFwFnjadNkqTxG/HMIMkXgX2BWUnWAkcD+yaZT9elswb4W4CqWpXkTOBa4EHg8Kp6qNVzBHAuMANYUlWr2ireDpye5P3Ad4GTJ2zrJEmjMmIYVNUr+hQPecCuquOA4/qUnwOc06f8Brq7jSRJU8RvIEuSDANJkmEgScIwkCRhGEiSMAwkSRgGkiQMA0kShoEkCcNAkoRhIEnCMJAkYRhIkjAMJEkYBpIkDANJEoaBJAnDQJKEYSBJwjCQJGEYSJIwDCRJGAaSJAwDSRKGgSQJw0CShGEgScIwkCRhGEiSMAwkSRgGkiQMA0kSowiDJEuS3JZkZU/ZDkmWJbm+/d2+lSfJCUlWJ1mRZM+eZRa1+a9Psqin/GlJrmnLnJAkE72RkqThjebM4BRg4aCyo4Dzq2oecH57DXAAMK89FgMnQhcewNHA3sBewNEDAdLmWdyz3OB1SZI2shHDoKouAu4YVHwQsLQ9Xwoc3FN+anUuBbZLshOwP7Csqu6oqjuBZcDCNu3RVXVJVRVwak9dkqRJMt5rBjtW1S0A7e9jW/nOwE09861tZcOVr+1T3leSxUmWJ1m+bt26cTZdkjTYRF9A7tffX+Mo76uqTqqqBVW1YPbs2eNsoiRpsPGGwa2ti4f297ZWvhaY0zPfLsDNI5Tv0qdckjSJxhsGZwMDdwQtAs7qKT+03VW0D/Dz1o10LrBfku3bheP9gHPbtLuT7NPuIjq0py5J0iSZOdIMSb4I7AvMSrKW7q6g44EzkxwG/Aj4yzb7OcCBwGrgPuDVAFV1R5L3AVe0+Y6tqoGL0q+ju2Npa+Cb7SFJmkQjhkFVvWKISc/vM28Bhw9RzxJgSZ/y5cDuI7VDkrTx+A1kSZJhIEkyDCRJGAaSJAwDSRKGgSQJw0CShGEgScIwkCRhGEiSMAwkSRgGkiQMA0kShoEkCcNAkoRhIEnCMJAkYRhIkjAMJEkYBpIkDANJEoaBJAnDQJKEYSBJwjCQJGEYSJIwDCRJGAaSJAwDSRKGgSQJw0CSxAaGQZI1Sa5JcnWS5a1shyTLklzf/m7fypPkhCSrk6xIsmdPPYva/NcnWbRhmyRJGquJODN4blXNr6oF7fVRwPlVNQ84v70GOACY1x6LgROhCw/gaGBvYC/g6IEAkSRNjo3RTXQQsLQ9Xwoc3FN+anUuBbZLshOwP7Csqu6oqjuBZcDCjdAuSdIQNjQMCjgvyZVJFreyHavqFoD297GtfGfgpp5l17ayocrXk2RxkuVJlq9bt24Dmy5JGjBzA5d/ZlXdnOSxwLIk/z3MvOlTVsOUr19YdRJwEsCCBQv6ziNJGrsNOjOoqpvb39uAr9H1+d/aun9of29rs68F5vQsvgtw8zDlkqRJMu4wSPLIJI8aeA7sB6wEzgYG7ghaBJzVnp8NHNruKtoH+HnrRjoX2C/J9u3C8X6tTJI0STakm2hH4GtJBur5QlV9K8kVwJlJDgN+BPxlm/8c4EBgNXAf8GqAqrojyfuAK9p8x1bVHRvQLknSGI07DKrqBuDP+pT/FHh+n/ICDh+iriXAkvG2RZK0YfwGsiTJMJAkGQaSJAwDSRKGgSQJw0CShGEgScIwkCRhGEiSMAwkSRgGkiQMA0kShoEkCcNAkoRhIEnCMJAkYRhIkjAMJEkYBpIkDANJEoaBJAnDQJIEzJzqBmh85h7171PdhN9La45/4VQ3QZoSnhlIkgwDSZLdRNLvsPtNmyvPDCRJhoEkyTCQJGEYSJIwDCRJGAaSJKZRGCRZmOT7SVYnOWqq2yNJm5NpEQZJZgCfAg4AdgNekWS3qW2VJG0+pkUYAHsBq6vqhqr6JXA6cNAUt0mSNhvT5RvIOwM39bxeC+w9eKYki4HF7eUDSVZOQtumq1nA7VPdiCm0uW+/RD44rsWe0K9wuoRB+pTVegVVJwEnASRZXlULNnbDpiu3f/PefmmiTZduorXAnJ7XuwA3T1FbJGmzM13C4ApgXpJdk2wFHAKcPcVtkqTNxrToJqqqB5McAZwLzACWVNWqERY7aeO3bFpz+yVNmFSt1zUvSdrMTJduIknSFDIMJEkbPwySVJKP9rx+S5JjNsJ63jno9X9N9DomykTukyTbJfm7cS67Jsms8Sw7XkkeSnJ1kpVJvpTkEeOo47MD31DflN53aTqbjDODB4A/n4SDzu8cFKrqf2zk9W2Iidwn2wF9w6AN8zHd3F9V86tqd+CXwGvHWkFVvaaqrm0vN6X3XZq2JiMMHqS78+ONgyckmZ3kK0muaI9n9pQvS3JVkn9N8sOBA2eSf0tyZZJV7RvJJDke2Lp94vx8K7un/T0jyYE96zwlyV8kmZHkw229K5L87UbfE781nn1yTJK39My3Mslc4HjgSW3bP5xk3yQXJPkCcE2bd719Nk1cDDwZIMmb2jatTPKGVvbIJP+e5Hut/OWt/MIkCzbB912avqpqoz6Ae4BHA2uAbYG3AMe0aV8AntWePx64rj3/JPCO9nwh3beRZ7XXO7S/WwMrgccMrGfwetvflwJL2/Ot6Ia92JpuWIt3t/KHAcuBXTf2/tiAfXIM8JaeOlYCc9tjZU/5vsC9vdsyzD5bM7BfJ+vR877MBM4CXgc8jS64HglsA6wC9gD+AvhMz7Lbtr8XAgs2tffdh4/p/JiU7xlU1V1JTgWOBO7vmfQCYLfkN6NRPDrJo4Bn0f1npqq+leTOnmWOTPLS9nwOMA/46TCr/yZwQpKH0QXLRVV1f5L9gD9N8rI237atrhvHu51jMY59MhaXV1Xvdox1n21MWye5uj2/GDiZLhC+VlX3AiT5KvBs4FvAR5J8EPhGVV08hvVMy/ddmq4m80tnnwCuAv5PT9kWwDOqqvdgSHqOhIPK96U7WD6jqu5LciHw8OFWWlW/aPPtD7wc+OJAdcDrq+rcMW/JxBnLPnmQ3+3WG2677+1Zbl/GuM82svuran5vwVDvd1X9IMnTgAOBDyQ5r6qOHc1Kpvn7Lk07k3ZraVXdAZwJHNZTfB5wxMCLJAMHie8Af9XK9gO2b+XbAne2g9ofA/v01PWrJFsOsfrTgVfTfdocOAicC7xuYJkkf5jkkePcvHEZ4z5ZA+zZyvYEdm3ldwPDnTkMt8+mi4uAg5M8or0HLwUuTvI44L6qOg34CG37B9nk3ndpOprs7xl8lG7o4QFHAgvahbxr+e2dJe8F9ktyFd0P3txCd9D7FjAzyQrgfcClPXWdBKwYuJA4yHnA/wS+Xd3vJQB8FrgWuCrdUNj/ytQMzzHaffIVYIfWxfI64AcAVfVT4D/bBdYP96l/uH02LVTVVcApwOXAZcBnq+q7wJ8Al7dtfhfw/j6Lb6rvuzStTMvhKFo/70PVjVn0DODEwV0LkqSJM10/ET0eODPJFnT3ov/vKW6PJP1em5ZnBpKkyeXYRJIkw0CSZBhIkjAMNMWSvKuNmbSijTG09zjrmT9oLKKXJDlq4lrad537JhnTwHhJHpbk221bXz5o2ilJbmzTvpfk+RvQtt+M7CqNxnS9m0ibgXbb8IuAPavqgXSDEW41zurmAwuAcwCq6mw2/u9o70s3ztRYhs3eA9hymFul31pVX07yXLrvUMwbT8Oq6jXjWU6bL88MNJV2Am6vqgcAqur2qroZIMnTkvxHG2313CQ7tfILk3wwyeVJfpDk2Um2Ao4FXj7wiTvJq5J8si1zSpIT043mekOS5yRZkuS6JKcMNCbJfkkuSTda7peSbNPK1yR5byu/Jskfpxsx9rXAG9s6n927YUl2SDda7Ioklyb50ySPBU4D5rdlnjTMvrkE2LmnvvX2R5KnJLm8Z5657cuFvxnZdajtSrJXujGgSHJQkvuTbJXk4UluaOVHJrm2bcPpY31ztWkxDDSVzgPmtIP6p5M8B6ANFfHPwMuq6mnAEuC4nuVmVtVewBuAo9u3i/8BOKO630o4o8+6tgeeRzds+NeBjwNPBf6kdTHNAt4NvKCq9qQbzfRNPcvf3spPpBs9dg3wL8DH2zoHD6L3XuC7VfWndL+5cGpV3Qa8Bri4LfP/htk3C4F/G25/VNV1wFZJntiWeTnd8Ca/Mcx2XUV3lgLdcB0rgacDe9N9CxzgKGCPtg1j/t0JbVrsJtKUqap70g1E92zgucAZrZ9/ObA7sCzdGHYz6IYkGfDV9vdKuiG8R+PrVVVJrgFuraqB33pY1erYBdiNbmgP6LqrLhlinX8+ivU9i24Ibqrq/yZ5TJJtR7Hch5N8CHgsvx1H6o8Yen+cSTeO1/F0YfA71yFaHettV/t2/+okTwH2Aj5GN3THDLrRZAFWAJ9P8m+0YNLvL8NAU6qqHqL7fYIL24F6Ed0Bd1VVPWOIxR5ofx9i9P+GB5b5dc/zgdczW13LquoVE7TOfiOxjuYbnm+lC54jgaV0v/UQht4fZwBfal0+VVXX92nHUNt1Md3YX78Cvk03PtQMut/XAHghXUC8BHhPkqdW1YOj2AZtguwm0pRJ8kdJei+Qzgd+CHwfmN0uMJNkyyRPHaG6kUZvHcmlwDOTDPzy2iOS/OEGrPMi4K9bXfvSdTPdNZqGVNWvgX8CtkiyP8Psj9bV9BDwHrpgGMt2XUTX1XZJVa0DHgP8MbAq3VAwc6rqAuBtdD+vus1o2q9Nk2GgqbQNsHTgIiVdd8Yx7RrAy4APJvkecDUw0i2cF9D9KNB6t2yORjsYvgr4YmvLpXQHxuF8HXhpvwvIdL9Mt6DVdTzdGc9Y2lN0o7S+bRT74wzgbxh0vWAU23UZsCNdKEDXLbSirXsGcFo7W/su3bWRn41lG7RpcWwiSZJnBpIkw0CShGEgScIwkCRhGEiSMAwkSRgGkiTg/wNFFmP2G6HQpwAAAABJRU5ErkJggg==\n",
      "text/plain": [
       "<Figure size 432x288 with 1 Axes>"
      ]
     },
     "metadata": {
      "needs_background": "light"
     },
     "output_type": "display_data"
    }
   ],
   "source": [
    "plt.hist(data['reviews.rating'], bins = 3)\n",
    "plt.xticks(range(3),['Negative','Neutral','Positive'])\n",
    "plt.xlabel('Sentiment of Reviews')\n",
    "plt.title('Distribution of Sentiment')\n",
    "plt.show()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 97,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "<matplotlib.axes._subplots.AxesSubplot at 0x1ce4b9464c8>"
      ]
     },
     "execution_count": 97,
     "metadata": {},
     "output_type": "execute_result"
    },
    {
     "data": {
      "image/png": "iVBORw0KGgoAAAANSUhEUgAAAPUAAADnCAYAAADGrxD1AAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAALEgAACxIB0t1+/AAAADh0RVh0U29mdHdhcmUAbWF0cGxvdGxpYiB2ZXJzaW9uMy4xLjMsIGh0dHA6Ly9tYXRwbG90bGliLm9yZy+AADFEAAAfRklEQVR4nO3dd3yb5bn/8c8lOXH23nbIYFkBs8omQKIXpQPoAE6BtqzSUhUxSsdp6Uz5dS/anp9+1aGT9gA9BVo66AIEJMyyUhyQA4EkxNnLK7bjoev3x6OUAE78yJZ0S4+u9+ullx1Hfu4r4K/vZ9xDVBVjTHCEXBdgjMkvC7UxAWOhNiZgLNTGBIyF2piAsVAbEzAWamMCxkJtTMBYqI0JGAu1MQFjoTYmYCzUxgSMhdqYgLFQGxMwFmpjAsZCbUzAWKiNCRgLtTEBY6E2JmAs1KZkiEhYRJ4VkT+7rqWcWahNKbkOSLsuotxZqE1JEJFa4Czgp65rKXcWalMqfgD8J5BxXUi5s1Ab50TkbGCLqj7tupYgsFCbUnAK8C4RWQP8BoiKyP+4Lal8ie3QYUqJiCwCPqWqZ7uupVxZT21MwFhPHUDpuogAs4CDgIOBmcBEYEL2457PJwAC9AG9b/i4G9gKbAY2ZT/u+fxVYE2kMW0/PCXIQl3m0nWRGuBk4BjgELwgHwSMKnDTu/CeKa8Ans9+bIg0ptcXuF0zAAt1GUnXRaqAo/FCfFL242ynRb1ZE/Bg9vVApDH9itNqKpCFusSl6yIz8QZlnAWcAYxxW1HOXgUeAO4H7ok0pnc4rifwLNQlKBFLHQicB5w7d81fuuevuedU1zXlSS9ewO8C7oo0prc5rieQLNQlIhFLjQb+A7gCWLjn69VdO/55yuNfPN5ZYYXTA9wL3Ar8PtKY7nRcT2BYqB1LxFIn4AX5QmDsm96g2nn6sk9oONNd6BtfLu3AG/OdiDSmX3VdTLmzUDuQiKXCwPl4Y52PGej9h6687YmajY+cUPDC3OsD/gj8KNKYftBxLWXLQl1EiViqGrgM+BTeYydfxrQ3PXz8U99YOPA7A+U54HvArZHGdJ/rYsqJhboIErHUSOBq4BPAjJwPoJntix+6doKg4XzXVgbSwBcjjem7XBdSLizUBZSIpQS4BPgqUDuUYx3R8ON/Tdm+4si8FFaengI+H2lM/8N1IaXOxn4XSCKWigJPA79kiIEGWFezuHmoxyhzxwJ/T9dFHkjXRY5zXUwps546zxKx1Hzgh0BeZxlJpnft4qXXzcnnMctYBvgx8LlIY7rVdTGlxkKdJ4lYKoS3xtZXKdC46+Oe+uaqse3rfN9gqwDrgWsjjenfuS6klNjpdx4kYqnDgEeB71PAiRSv1i5uKtSxy1QNcFe6LnJ3ui4y5EucoLCeeggSsVQV8Dng88DwQrcX7u164fSHP7mg0O2UqTbg45HG9M9dF+Ka9dSDlIilavFmIn2FIgQaoC9cHemqnrCpGG2VobHAz9J1kV+n6yLlNuklryzUg5CIpd4BLMdbW6t4RKSpZtGLRW2z/HwQeCpdF6nYx38W6hwkYqmqRCz1TeAeYLKLGjZNPy7IY8Dz5VDg8XRdJOa6EBfsmtqnRCw1Bfgd4HYapGr3aQ9/cndV3+43T/4w/bkduDzSmN7tupBisZ7ah0QsdTDwOK4DDSAyfOOME1e4LqOMXATcl66LTHJdSLFYqAeQiKUWAo8BB7quZY/1s061XSxysxB4LF0Xme+6kGKwUO9HIpa6CLgPR9fP+9IxasbhGQn1uq6jzByCd50d+CmsFup9SMRSH8dblaPadS1vIjJ+2+QjnnNdRhmaCjyQrou8x3UhhWSh7kcilvokcBPemtglqal2UZvrGsrUSOCOdF3kPNeFFIqF+g0SsdSnge+6rmMgLePm2xjwwasCbk/XRd7lupBCsFDvJRFLfQb4tus6/NBQuKZl3LyVrusoY8Pweux3ui4k3yzUWdke+puu68jFutrFG13XUOaGA79L10XOdF1IPlmogUQsdSll0kPvbdvkw2e6riEAqoG703WRRa4LyZeKD3Uilno73vK0ZScTrj60c8QUm445dCOB36frIoe6LiQfKjrUiVjqCOC3eDdOytK62kUvu64hICYAf0rXRSa6LmSoKjbUiVhqFt7EjLIeQ7152rFlXX+JORi4M7sRYdmqyFAnYqlhePs5lf1qGT3DxhzRUzWyxXUdARIFEq6LGIqKDDXwHeBE10XkhUjVhpmn2ASP/LoyXRe5znURg1VxoU7EUufhLRAYGBtmnlJx/x+L4LvpushJrosYjIr6YchuERu4Naw6R049PCPhbtd1BMyeUWcTXBeSq4oJdXYfqzuBca5ryTuRsVumHm0TPPJvTuvI8hu/UDGhBm4EjnJdRKE01SzqcF1D0Lw8g2Xxq8Lvr7+l/lLXteSiIpYzSsRSx+KtXBLcDeY0s2nxQ9dMlxKeWVYuMrDjp28LvXjfMaE9N1NbgSMaLm1Ym8txRGQEsBRv1FoVcKeqfjm/1b5Z4HvqRCw1HPgFQQ40gIRmNI8/OO26jHLXPIpn4vFw916BBu+S7SeDONxuIKqqR+KdJb5dRAr+1CXwocZbaP9w10UUw7rZi7e4rqFcKXTfe5Q8dOW14aO3j5P+tht+a/0t9RfkdExPe/aPw7Kvgp8aBzrU2WGgN7iuo1h2TIzUuK6hHHWHefnzl4RX/+Qd4dMR2d/ly031t9TndKNVRMIishzYAtyrqk8MqVgfAh1q4L/wfjtWhEx4+MG7Rk7P6bqv0jXWsPRD14dnraoRP5M5ZuJtgOibqvap6lF4oxePF5GCnzUGNtSJWOpc4DTXdRTbutrFa1zXUA4ywtbE2aEnv3RJ1Wndw2RkDt96Vf0t9cfk2p6qNuNt0/T2XL83V4EMdfbm2Ldc1+HClmnHlN1giWLbMYanYleHeag+NJjN68N4+48PSESmisiE7OcjgTOAxkG0mZNAhhq4GqjINbx6q0Yd3j1s9A7XdZQiha57jpWlsWuqjm0eI1OHcKiF9bfU+1nfbCbwgIg8BzyJd0395yG060vgnlMnYqnJwCq8+bEVad7qPz08b+3fFrquo5TsruLFL10cDq2eIfn6Zf8CUN9waUPJbawQxJ76U1RwoAE2zjiprOcD55OCrpgjD11+fXhOHgMNsAB4fx6PlzeB6qkTsdQEYC1BHN+dC9WO05ddL+FMTy43gAInI2z+0btCTY8uCL2lQE2sAiINlzaU1G4pQeupr6bSAw0gMmrztLc0uC7Dpa3jeOLKa8JVBQw0ePdtLizg8QclMKFOxFKjCNg86aFYX3N6xWzdujeFjrtPlGXxeNUJraOlGHugXV+ENnISmFADHwGmuC6iVLSNqa1TpORu4hRS1zDSn7oivPm2xeFibjl8TP0t9YuK2N6AAhHqRCwVBj7puo6SIqGpOybWPe+6jGJQyDw7Xx66/PrwQeumyTwHJZRUbx2IUAPvAGa7LqLUrKtdvN11DYXWJ2z87rmhf33jgvDpfWFxNST47Ppb6g921PabBCXUH3FdQCnaOfGQOa5rKKRNE3jsI9eFRz55aOhox6WEgGsc1/Bvvh5piciP+vlyC/CUqv4h71XlILt+96sEfb70IB3/5NdWj9m1wcUpacEotN9xamj5nQtDpTTAZgcwq+HSBuc3KP321CPwJnm/lH0dAUwCrhCRHxSoNr8uwwK9T+tqo4GatdUxnOevvzK8vcQCDV4eSmJrXL8jjw7CW8GhF0BEfgz8A3gr4Ox5aCKWEuAKV+2Xg61Tj5wcWfk/rssYMoW+fx4iD9/03tApmZCU1og51ZYF3d0NV+1sORO4w3U5fv/j1ACj8U65yX4+S1X7RMTl6cZJwHyH7Ze83vDIw3YPH7e1urt1KBMYnOoL0fSt80M7lh8YOt11Lf+m2ju9r+/ZS1vaet/X1nZ0tbIQOIEl4z/DkhanE2r8hvrbwHIReRBvYbvTgK+LyGjgvgLV5sd7HbZdHkRC62ed1jh/zZ/LMtRNk3nkC5eED+8YISWxRdLITCb97vZdWz/a3BKZ0pd549TNYcB5DG49s7zxFWpV/ZmI/AU4Hi/Un1PVDdm//nShivPBQu3DxhknVs9fU/AZf3ml0Hrr4tCKP54YOsV1LSHVjad0dq28emdz7YLunggQ2c/bLyKHUIvIz4GzgS2qmpdVUXxP6BCRGmAOe/0iUNWl+ShiMBKxVD1gC9j7odp1+rJP9IUz3aNdl+JHezXP3XBZeNLmSQ57Z9X2g3t6lsd2tow+o6PzyJD/m8oZYBZLWjb7ebOInAa0A7/KV6h99dQi8i3gAuB5vKLBWxXRWaixXto/kREbZ5zweO2GZSW9KaBC7yML5JH/e05oYSYkxX+ioZqZ3Jd59oOtbV3vb207apTqYO6wh4AzgV/7a1KXisjcQbSzT36vqd8DHKqqzp/B7eU9rgsoJ+tnndpbu2GZ6zL2qTfE2q9fEGpfMbf4N8OqM5mXztrVsT62s+XQmX19+ZjVdQY+Q10IfkP9Ct5NgJIIdXZ1k8BuoVMIu0bPWqBIn6Al90x/zTQe/tLF4aO6hkvRRsCJ6tbju3a/cPXO5hlH7e4+FG/D+Xw5I4/HypnfUHfg3f2+n72CrarXFqSqgZ2KbS+TG5FJ2yYfvnzq9oaS+WWo0PzLM0Lpvx5XpIEkqp1ze3qfvbKlZfg72zuODkOhzgpmsWT8Apa0vFCg4++X31D/MfsqFRW39G8+NNUubpm6vTTWTmgdyfIbLgtP2zpBCrsHtKpOyGSeu7C1vfWSltYjx6qeXND2XrMYbx2zovP7SOuWQheSIwv1IDSPP9D5GHCFnofq5dEfnxU6VUUKNqFomOrqM3d1rI3vbDlodm/vkYVqZz9OBhIDvUlEbgcWAVNEpAn4sqr+bCgN7zfUIvJbVX2fiDTQzx5AqnrEUBofjEQsNRa7nh4UDVUd0Dr2gJfGtb3qZJpgT5jV/+eicFfjbCnIaa+o7jhq9+4V8Z0tk0/o2n0Y4PKXmK/n66p6Ub4bHqin3rM80Nn5bngITsQmcAzautro+sPSvyx6qFfNZNmSD4Tf0j1MRuX1wKrdtb29z1zR3Crvbt91zLDSOYubw5LxNSxpWV/shvcbalXdmP30KlX9zN5/l312/Zk3f1fB5bzliXnNtsn104rZXga23/yO0KrUUaG8LjE0ti+z4vy29h0fammtn5DJlOrz95NxMMHD742yt/LmAL+jn68VQ9FP+YOkL1wd6aqeuHHE7p0zC91W82ie+exl4Zod4+SEfByvSnXdoo7Ol6/Z2Txvfk9vOWxPfDilFmoR+RhwFTA/u3XIHmOBRwpZ2H5YqIdCRJpqTn/poFfuLlioFXb/4xh5/Gdnhk4bYGtYHwfTlsO7u5+7amfL+IWdXfVSXstW1blodKCe+jbgr8A3gM/u9fU2VS369LLsAoOHFLvdoNk0/fhRB71yd0GO3V3Fqi9/IJx5edYQboap9s7o63v2spbW3vPb2o+uVoq5Omg++dkeN+8GuqZuwZtDfRGAiEzDWwVljIiMUdVXC1/i68wHhhe5zcDpHj7uiN7wiNaqvq68bnyQns3Sr14YPr6nSkYM5vtHZTLp97Tt2nJlc8thkzNvmtZYjg5hyXhhSUtRt8HxO6HjHOD7wCxgC95srTRwWOFK65f10vkgMnzjzJOent30QF4GfmSEbf/vrNDqpfWhnO88h1U3nNLZ9dI1O5tr6wae1liyVOntJbx+J2O2rdNpu1ZmZmuDzhvxaOawmoegqZi1+L1R9lW8R0n3qerRIrKYbO9dZCUxUT4I1s9cqLObHhjycbaP4cnPXh6e2zJG/Pesqu2HdPf862PNLaOi3rTGWUMupAhU6djNsPXbGL9zdWZm5wt6gDRk5o9+QedMWavTa/oIz8Hr8PY2Hx+hFpHZwK+AGXgzIW9WVV/7YL+R31D3qOp2EQmJSEhVH8g+0iq2gt+xrRQdo6YflpFQT0gzg1orW6HrnuPkn786I+yvd1btm9KXWX5xa+vui1rbjxqp6nzxg/5kVHbsYsTGzTqxZZXO6lmRmRdeofPGNWYOmL6JSdPJfeLHXPxNUe4FPqmqz4jIWOBpEblXVXMeauo31M0iMiZb3K0isiVbRLFZqPNFZPy2KUc+M23rszk/999dxcovXhyuWjNDBgx0dSbz0tntHRs+1txSNz0/0xqHRBXtI7SpldGb1+vkthd1dt+KzNzqFZl5Ext19sw2Rk/CWxk0X3ydXWbHhGzMft4mImm8tQELFup3A51424t8ABgP3JhrY3lgoc6jdTWL2qZtfdb3+7N7PS/9xvtCJ/ZWSfW+3hdS3XJ8V1f6mp0tM47I/7TGAanS3UPV+h2M3b5Wp+9qzBxAg84b+Xxm7uRXdGbNbobPpHg/SzmvDZddNOFo4InBNDhgqEUkDPxBVc/AO9d3ObmjLK69ykXruHm+N2HPCJt/+O5Q02ORfSxioNoxv6f32SubW0a8fVfHUQWc1phtjrZOqjds1fE7X9GZXS/o3PBzmXlj0jpn6jqdOksJzcPt2O89ctq0MXtGfBfwcVVtHUyDA4Y6uwxwh4iMzz7icqmoQxyDTkPhmuZx8xsntL6y30ESW8bzxA2XhQ9uGyWvP31W1YmZzPKLWtt2XdzSduSYPF8nZ1S2tjNy80ad1PKS1vSsyMwb5l3fzp65jQlTcPQcOEe+T+VFZBheoG9V1d8NtkG/p99dQIOI3Avs2vNFB4sklMXCeeVk3ezopgnP9x9qhY67T5Knb1/0+q1hh6u+8rb2Xa9e1dxycG1v36D3sVKlr5fwxhZGb2nSqbsaM7P7Vui8ESsy8ya+pDU1uxg5lUGcvpaY8X7eJN7Iu58BaVX9/lAa9Bvqe7Iv1/Z5HWcGZ/ukBf1eW3YOI/2FS8Ij1k2TUwFEdfsxXbtXxJtbph7XtXsBPjdRUKVrN8PWb2fc9rWZ6Z1pnUNDZt7o53XulNU6o6aXqlqC/ajSV6jxpmpejNd5Ls9+7XOq+pdcGyy3RRIGNVLJ7FsmXH1ox8gpTaM6t9VCdq/nA2XZd84LndwXIjO7p+exDze3hs9p33X0sH1cJ6vSsosRG7boxJ0v68zu53VuuCEzb2xj5oAZ65kyHeRA4MCi/sNKh6+ppqr6MHlaomvQexKJyBJVXZKPIvzIjvu2edQF0FSz+OVDVt1R2yds/N65oU0vHqiTLm9rffyyltYjxmf0JFU0g2xuZtTmDTq57UWt7WvIzB+2IjN3wkqdPbOZsRPx3yNVmqL/zA5lo7Gn81aFP9ZLF8jmaW8ZN2PLbx++89xhLRf29o2YvGb0sMZMnX5D5zWuyMydvEprarqonoE32snkpnxCrap/ymchPgxq5JMZWM+wMUc9eUxi55w1r+1VDN6FbvZitzP7MjnS1zaVLBq/Ezq+jTf+uxP4G3Ak3nO0Yu6R2lXEtiqLd+s1n6OoTJZAW7Hb9Lua45nZB+Fn4w1OP4Qib4wXT0a7eG3LH2PKRV+xG/Qb6j2nvu8EbnexQEKWnQKaclP0n1m/of6TiDQCxwL3i8hU3JwOdzho05ihKHoH6CvUqvpZ4CTgWFXtwQvXuwtZ2D5YqE252VnsBv3eKFuGN+1ymYg8oqpt7DVctIiKftPBmCEqzZ4auBRYCZwHPCoiT4nITYUra582DvwWY0pK0UPtd5joKyLSCXRnX4txs5ZUUdd6MiYPin767aunFpGXgbuB6XgzSQ5X1bcXsrB9sFCbclP0s0u/p98/Al7FW2zwWuBSEXExQL/o+xIZM0Srit2g37vfP1TV/wDOwBvzvQR4sYB17Yv11KbcvFzsBv3e/f4esBAYAzwGfAlYVsC69mWNgzaNGaxOHJxd+p3Q8TjwbVXdXMhifHgR6MEmd5jy8Eo8GS3q7hzg/5r6LuCtIvJFABE5QESOL1xZ/Ysnoz1AY7HbNWaQin7qDf5DncAbUfb+7J/bsl9zocFRu8bkaoWLRv2G+gRVjZMd762qO3G3Ud1zA7/FmJLwTxeN+g11T3b9bwXITuhwNQ3SQm3KxaAW4x+qXJ5T/x6YJiJfAx4Gvl6wqvbvGUftGpOLpngyuslFw36fU98K/Cfe5vMbgfeo6h2FLGxf4snoZrxx6MaUsiddNbzfR1oiMk5VW0VkEt6+1Lfv9XeTHC6W8CDlsTuDqVxOrqdh4OfUt+EtYfQ02evpLMn+2deC7gXwIPBRR20b40fKVcP7DbWqnp39WAobje3tQdcFGLMf24CnXDXud5bWH0TkIhHxtdtAoWVvQNggFFOq/hFPRp0tkun37vf3gVOBtIjcISLni4jrxfX/5rh9Y/bF6c+m37vfD6nqVXjX0DcD78O7cebSXY7bN6Y/CvzdZQG+d+gQkZHAOcAFwDG43Xwe4FFgE7YVjCktT8WTUacdnt9r6v8F0kAUb8z3gap6TSELG0j2muX3Lmswph+/cV2A3576F8D7VbXouw0M4C7gY66LMCYrw15jOVzxe6NsKXCDiNwMICIHi8jZhSvLt4fwHh8YUwpS8WTU+Yq3fkP9C7xVRE/O/rkJb8M8p+LJaC8l8JvRmKxibhi5T35DfaCqfhtv1RFUtZM87XqfBz9xXYAxeEsX/c51EeA/1N3Zu997pl4eCOwuWFU5iCejDTgcZ2tM1p3xZLQkdpAZMNTe1sUk8R6ozxaRW4H78WZtlYofuy7AVLwfuC5gjwHvfquqish1wJnAiXin3depaindoPoN8F1gsutCTEVaFk9GS2aev9/T78eB+ap6j6r+ucQCvWdDeru2Nq6UTC8N/kO9GHhMRF4WkedEpEFESm1ZoZuwrW5N8a3G25KqZIjqwMsSi8ic/r6uqmvzXtEQJGKpm4CPu67DVJTr48loSfXUfne9LKnw7sd38EaYVbsuxFSEjcB/uy7ijfyefpeFeDK6Afi56zpMxfhqPBntdF3EGwUq1FnfJDtIxpgCWk2J3pwNXKjjyeirwH+5rsME3pLsNlAlJ3ChzroR2Oq6CBNYL1Ai47z7E8hQx5PRFuCLruswgfUpl2uQDSSQoc76KbZFj8m/P8ST0b+6LmJ/AhvqeDLahz2zNvnVSRn8TAU21ADxZPQB4Neu6zCBsSSejK5xXcRAAh3qrOuADa6LMGXvX3hLZZe8wIc6nozuBK50XYcpa93Ah7Ir7ZS8wIcaIJ6M3oP7JY1N+fpCKU2tHEhFhDrrOry11YzJxf14c/XLRsWEOvvs+gNAWZxCmZKwA7g0nowOPJWxhFRMqAHiyehS4AbXdZiy8eF4MrredRG5qqhQA8ST0e9i+3CZgd0UT0bLcgeYigt11uXAStdFmJL1N+DTrosYLF8rnwRRIpZaADwBjHFdiykpK4ETsvdgylKl9tTEk9EXgPOxudfmNTuBc8o50FDBoQaIJ6N/Bz7sug5TEnqBC+LJ6EuuCxmqig41QDwZ/RXwedd1GKcywMXxZPRe14XkQ8VeU79RIpZKAFe5rsMUnQJXxpPRn7ouJF8qvqfeyzXYjK5K9IkgBRos1P+WXcniMmw10kry5VJbszsfLNR7yQb7w5TgWs4m774QT0ZvdF1EIdg19T4kYqkf4Z2Sm2DJAFfFk9HA/uK2nnof4snotcDXXddh8qobuDDIgQbrqQeUiKUuA24GhjkuxQxNO/DeeDJ6n+tCCs1C7UMillqENwlkkuNSzOCswQv0cteFFIOdfvsQT0YfBE4CVjkuxeTufuDYSgk0WKh9iyejLwInACW95rN5ne8Db4sno9tdF1JMdvqdo0QsJXgLLdwIhB2XY/rXAXwknoze5roQFyzUg5SIpU7F20/pANe1mNf5J9447hddF+KKnX4PUjwZXQYcCfzWdS0G8GZZLQFOqeRAg/XUeZGIpc7F2z53lutaKtRKvN75SdeFlAILdT9EZA3QBvQBvap67EDfk4ilxuNteP9RQApaoNmjG7gJ+Eo8Ge10XUypsFD3IxvqY1V1W67fm4ilFuINVonkuy7zOn8Hrq30U+3+WKj7MZRQAyRiqeHAx4AvAFPyWJqBtcD15brSZzFYqPshIqvx1qtS4L9V9ebBHCcRS40DPoO3/emo/FVYkVrwdsr4np1q75+Fuh8iMktVN4jINOBe4BpVXTrY4yViqVnAV/CWJrZn27lpx7sJ+Z3sZodmABbqAYjIEqBdVYe8n1IilpoHXA98CBg91OMFXCtemG+qtBFhQ2WhfgMRGQ2EVLUt+/m9wI2q+rd8tZGIpSbhXXNfA0zP13ED4kUgAdxS7kv1umKhfgMRmQ/suQlTBdymql8rRFuJWKoa+CBwBd6EkUqVAf6MF+Z7y21DulJjoS4RiVjqELw10i4BatxWUzQrgf8FfhFPRtc4riUwLNQlJhFLhYC3AhcCZwFT3VaUd2vwgvybSpoOWUwW6hKWDfjxwDnZV73bigalF2+SxX3AX+LJ6BOO6wk8C3UZScRSc4BFwMnZ1wJKb1JOBkgDKbybjA/Gk9E2tyVVFgt1GcuONz8R7ybbYUAdcDBQXaQSeoAXgGeyr2eB5fFkdFeR2jf9sFAHTPaUfQ5ewA8BaoEZwExgcvY1CRiOd3e/v8knu/CeE+95tQBNeNfDa/CGaq4BmuLJaG+h/i1mcCzUFS77SyCMF/Aw0JHd1MCUKQu1MQFTajdZjDFDZKE2JmAs1MYEjIXamICxUBsTMBZqYwLGQm1MwFiojQkYC7UxAWOhNiZgLNTGBIyF2piAsVAbEzAWamMCxkJtTMBYqI0JGAu1MQFjoTYmYCzUxgSMhdqYgLFQGxMwFmpjAsZCbUzAWKiNCRgLtTEBY6E2JmAs1MYEzP8HGmPKHO2nB0YAAAAASUVORK5CYII=\n",
      "text/plain": [
       "<Figure size 432x288 with 1 Axes>"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "data['reviews.rating'].value_counts().sort_values().plot.pie()"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "**Data Preprocesssing**"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 41,
   "metadata": {},
   "outputs": [
    {
     "name": "stderr",
     "output_type": "stream",
     "text": [
      "[nltk_data] Downloading package punkt to C:\\Users\\Aman\n",
      "[nltk_data]     Chauhan\\AppData\\Roaming\\nltk_data...\n",
      "[nltk_data]   Unzipping tokenizers\\punkt.zip.\n",
      "[nltk_data] Downloading package stopwords to C:\\Users\\Aman\n",
      "[nltk_data]     Chauhan\\AppData\\Roaming\\nltk_data...\n",
      "[nltk_data]   Unzipping corpora\\stopwords.zip.\n"
     ]
    },
    {
     "data": {
      "text/plain": [
       "True"
      ]
     },
     "execution_count": 41,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "nltk.download('punkt')\n",
    "nltk.download('stopwords')"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 158,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Negative English Words:\n",
      "       2-faced\n",
      "0     2-faces\n",
      "1    abnormal\n",
      "2     abolish\n",
      "3  abominable\n",
      "4  abominably\n",
      "\n",
      "\n",
      "Positive English Words:\n",
      "            a+\n",
      "0      abound\n",
      "1     abounds\n",
      "2   abundance\n",
      "3    abundant\n",
      "4  accessable\n"
     ]
    }
   ],
   "source": [
    "neg_words=pd.read_csv(r\"C:\\Users\\Aman Chauhan\\Desktop\\negative-words.csv\")\n",
    "pos_words=pd.read_csv(r\"C:\\Users\\Aman Chauhan\\Desktop\\positive-words.csv\")\n",
    "print(\"Negative English Words:\\n\",neg_words.head())\n",
    "print(\"\\n\")\n",
    "print(\"Positive English Words:\\n\",pos_words.head())\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 75,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "<matplotlib.axes._subplots.AxesSubplot at 0x1ce48c53f48>"
      ]
     },
     "execution_count": 75,
     "metadata": {},
     "output_type": "execute_result"
    },
    {
     "data": {
      "image/png": "iVBORw0KGgoAAAANSUhEUgAAARQAAADnCAYAAADfAal6AAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAALEgAACxIB0t1+/AAAADh0RVh0U29mdHdhcmUAbWF0cGxvdGxpYiB2ZXJzaW9uMy4xLjMsIGh0dHA6Ly9tYXRwbG90bGliLm9yZy+AADFEAAAdjUlEQVR4nO3deZhcVbnv8e+bkYShGRWQIRrCmI1hFAgQBsED4Toh6IGrGxWOeDziUdSDOMXhMik4IsJFpPQiYRYQIoOYBAIKGoYVwkwgZOjM6UyddHfVe//Yu02n6XTXsKrWrqr38zx5Oqmu2vuN0r+svfba6xVVxRhjfBgUugBjTOOwQDHGeGOBYozxxgLFGOONBYoxxhsLFGOMNxYoxhhvLFCMMd5YoBhjvLFAMcZ4Y4FijPHGAsUY440FijHGGwsUY4w3FijGGG8sUIwx3ligGGO8sUAxxnhjgWKM8cYCxRjjjQWKMcYbCxRjjDcWKMYYbyxQjDHeWKAYY7yxQDHGeGOBYozxZkjoAkxtRblIgF2AUcCewK7pn3cG3gFsAQwDhvbxtQCsBFakv5b3+v1c4EVgjotdoVZ/J5MdYs3SG1eUi0YA7wUOBQ5Jf+0NDK/yqdcDr5CES/ev54FZLnb5Kp/bBGSB0kCiXDQaOAk4nCQ89idbo9DVwN+Ax4BpwBMudh1hSzI+WaDUsSgXDQWOBiYCpwH7hK2oZOuAR4GHgbtd7F4JXI+pkAVKnYly0bbAh0hC5GSgJWxFXs0EbgZucbF7K3QxpnQWKHUiykXHAucBHyOZOG1kCswgCZfbXOyWBK7HFMkCJcOiXLQTEAPnUn+XM77kgfuBq1zspgauxQzAAiWD0tHIF4EPktyyNYmZwFUkl0RdoYsxb2eBkiFRLjoF+CYwPnQtGTcP+DlwnYtdW+hizEYWKBkQ5aJTge+T3Oo1xVsN/Aq41IIlGyxQAopy0fHAD4GjQtdS55YCk4Br7VIoLAuUAKJctCfJkP2DoWtpMC8CX3exuzd0Ic3KAqWG0oVoXwG+A4wMXE4j+ytwoYvd06ELaTYWKDUS5aKjgWuAsaFraRIFkvmVi1zs1oYupllYoFRZlIt2AH4EnANI2Gqa0hzgsy52fw1dSDOwQKmiKBd9APg9sFPoWpqckoxWvuZi1x66mEZmgVIFUS4aAvwA+B9sVJIlLwBn29xK9VigeBblot2AydjitKzqJJlXuSp0IY3IAsWjKBedBtwI7BC4FDOw3wH/4WK3IXQhjcQCxYMoFw0GLgMuxC5x6snfgY+42C0MXUijsECpULrN4s0ke5SY+jMf+LCL3T9CF9IIbNf7CkS5aHuS3cYsTOrXu4BHo1x0VuhCGoEFSpnS5fMzsOdwGsEWwE1RLvpO6ELqnV3ylCHKRe8FppC0nzCN5RIXu2+GLqJe2QilROkTwtOxMGlUF0e56IrQRdQrG6GUIA2T+4ARoWsxVfdTF7svhy6i3ligFCnKRUcBDwJbhq7F1MwvgQtc7OyHpEh2yVOEKBcdQjJnYmHSXP6L5BkgUyQLlAFEuWgMSZhsE7oWE8T5US76dugi6oVd8vQjykW7AI+TNBY3ze0sF7ubQxeRdRYomxHloi1JwuTA0LWYTNgAnOBi93joQrLMLnk27zdYmJiNhgN3R7noPaELyTILlD5EuejLwMdD12EyZ0fgvrS/tOmDXfL0knbt+wswJHQtJrP+AnzAxS4fupCssRFKD1Eu2hW4FQsT078TAbvz0wcboaTSFhdTsYf9THHywIkudtNCF5IlNkLZ6AosTEzxBovq/239wfbbhS4kSyxQ+FfPnC+FrsPUj5GFwuw757cO2TmfvzZ0LVnS9Jc8US4aDjwL7BO6FlMHVAvHtq9/9KeLlhw1FIamr57NpLY/BK0rI2yEAt/FwsQUYbDqgl8sXvrc1YuWTOgRJgBXM6nlXcEKy5CmDpQoFx0EfC10HSb79uzsfGLa3HlbHreufVwf394WsLYcNPElT9qM60ngoNC1mAxTXf1fK9qe+1zbqmL6LB3PpLap1S4py5p5hPJVLExMP7YqFGbdO2/hiiLDBODnTGoZXOp5RERF5Moef/6qiEwq9ThFnOfiXn/2/lxSUwZK+hSxLUwyfVPNn7R23bRH35y376iurj1K+GQEfL6MM24APioiO5bx2VJsEiiq6n2ZRFMGCkmYjAxdhMmeIapv/XrRktlXLV46YUh5K6a/z6SWUjtHdgHXAW/bclJEdhKRO0TkqfTX+B6vPyQiM0XkWhF5szuQROSPIvJPEXleRP4jfe0yYISIPCMiN6WvrUm/3iIip/Y4540icrqIDBaRH6XnfU5EPjfQX6TpAiXKRaOBc0PXYbJnr46OGdPfnNcyvn19VMFhtgP+Txmfuxo4W0Raer3+M+AnqnoYcDpwffr6d4FHVPVg4C6g50jqM6p6CHAocIGI7KCqFwHtqjpOVc/udY7JpA/DisgwkkcL7gc+C7Sl5z4MOE9E3t3fX6LpAgX4AZve8jPNTrXtwmUrHr9rfuv4rVV97Mx3HpNaxpZWgq4i6bd8Qa9vvR/4pYg8A9wDbCMiWwNHkwQBqvpnYEWPz1wgIs8CfwN2B8YMcPopwAkiMhw4BZiuqu3AycCn0nP/naRnd7/HaqqH4NJ+Op8IXYfJjpZ8/tnJC1p33K0r73M+YRDwHeDMEj/3U2Am8Ntexzoy/QH/FxHps4e2iBxHEkJHquo6EZlK0shss1R1ffq+D5CMVLp3phPgi6r6QLF/gWYboVyKNTM3AKpdE9esnTZ97vxot658NRalnc6klv1LK0mXkzzt/tkeLz9Islk2ACLSvQ7mMdLAEpGTSS61AFqAFWmY7Asc0eNYnSKyudH5ZODTwDFAd4A8AHy++zMisreI9LtRe9MESvq8zimh6zDhDVF984bWxS9ftmTZhEHV+xkYBJTTgfBKko2cul0AHJpOis4Gzk9f/x5wsojMJPnveiGwGvgzMEREniO5vP9bj2NdBzzXPSnby4PAscDDqtqRvnY9MBuYKSKzgGsZ4KqmaRa2RbnoT8DE0HWYsPbb0PHYjQsXHTRStRYtUfLAGCa1zfF94HS+I6+qXSJyJHCNqva1iremyp5DEREH9JVGAqiqZmY/1igX7Q2cOuAbTcMS1RUXL1vx0idWrzm6hqcdTHIruPdEqw97ALeKyCCgAzivCucoWdkjFBHZs7/vq+qbZR24CqJcdDXwn6HrMGFsl88/fcv81p13yedD9KNeC+zBpLblAc5dc2VfP6rqm92/0pfGpL9fDGTmf7woF7UAceg6TACqHR9dvWbatLnzxwUKE0i6TTbNuqeKJ6RE5DzgdpIJG4DdgD9WelyP/jfWQrTpDFN9/fcLF73+vaXLJ0j4O3tN8w+ajxnuLwDjgVUAqvoK8A4Px/VlwOXCprEcuH7DozPenLfLuA0d+4auJbU/k1oOC11ELfhY2LZBVTu619mIyBD6nqytuSgXHUXywJZpAqK69HtLl7/+kTVrjwldSx9i4KnQRVSbjxHKtPSx6BEichJwG3Cvh+P6cFboAkxt7NiV/8fDby0ofGTN2sND17IZ/86klmGhi6g2H4FyEbAEcCSXF/cD3/Jw3IpEuUiAD4euw1SZ6oZ/b1s9/ZG35h/yjnw+S5favW0PnBa6iGqr+JJHVQsikiN5eEiBlzQbq+XeB9g+nw1seKHwyo0LFzO2o+PY0LUUKQbuDF1ENfm4yzMReA34OfBL4FURycIS94+GLsBUiaoe2r5++oy583Yf29Ex0JO0WXIKk1q2D11ENfmYlL0SOF5VXwUQkdHAfSSPRIdkgdKABqkuvmTJsrkT166rl1FJT0NJnui9eaA31isfcyiLu8Mk9TrJ4rZg0m0KRoeswfi3c1fXk4/MnT9o4tp1h4aupQIN/QhIJc/ydI8AnheR+0keu1bgDMLfHrPRSSNRbT+nbfU/LlyxMou3g0v1b0xqGcSktkLoQqqhkkue/9Xj94uACenvl7Bxb4ZQsjCHYzwYUSi8+PsFi4bt09lZt2Giiq5j+Et/L+y36Jb88S3TCgce9CL8M3Rd1VB2oKjqp30W4kuUi0Zi7THqn6oe1b5++i8WLTlyGNTd+o28SutLuvtrf8wfLXfkj9l7GS37At0rd9+PBUrfRGQLkh2mDqDHVnOq+plKj12mw2iyrS0bzSDVhT9evHThSevaJwz87mxQpX0JLbMfyh+yZnL+hF2dvmcMsPNm3n4icHkNy6sZHz94vwdeJJm9/j5wNvCCh+OWy3uvEVM7u3V2/e3mBa37bFsoHBy6loG067CXnyzsu/DW/HFbP1w4eP8NDDukyI8eMeqi++SNyyZmYb2WVz4CZS9VPUNEPqSqORH5Axv3pAzhyIDnNuVSXXv+ylVPf2FlWy03QCpJXmXJa7rrK3fnx+vt+WPHLGL7vYG9yzjU1sA+JP8QNxQfgdKZfl0pImOBVmCUh+OWywKlzmxZKMy+aUHryNGdXZkKE1U2LGOb2X/JH7xqcv74XZ7WvcaA7OTp8IdhgdKn60RkO5JufPcAW5G0EKi5dKvHardzNL6oFo5b1/7oTxYvHV9mlz7v1uvQ12YWxsy7NX/clg8UDtu/neHVmuA/lGS6YEAiosBVqnph+uevAlup6qRSTyoi2wJnqeqvyvjsG8Chqrp0c+/x8SxPdyezacB7Kj1ehY4Y+C0mCwarzv/ZoiVLJ7SvDzrxWlBZ9rru/NI9+aMKt+cnjF7AjqOpzaLIUhbndfc+vrS/H+YibUuyHerbAkVEBqtqvpKDV7Kw7Sv9fV9Vryr32BXIyoY6ph+jOjof/38LWw9oKWjNH95UpXMFW82eWhi38uauE97xlO6zL0iIifxxoy66b9Abl00sZoFbz97Hm7TmEJGdgF+zsRXpf6vqDBGZBKxR1R+n75tF8rTzZcDotBvgQySPyXyXpA3HOGB/EfkjScfBLYCfqep1xf6lKhmhbF3BZ6vFlttnmeqqL61oc+e2rRpfy9Nu0CFzntG93rotP2HElPzh+61lxHtref7NGEnyQ1vsZu5Xk/TUuaLX6929jx8TkT1Ibojs189xLgLGdrfcSDsNHp6+1t3u4zOqulxERgBPicgdqrqsmCIrWdj2vWLeJyLfUNVLyz1PiUJfcpnN2DpfcDcvaN12z66uqodJQVk5V9/54p8KR3Temj/u3XP1ne8G+m3yHcgYigwUVV0lIt29j3u2JX0/yaii+8/dvY9L8WSPMIGkN/JH0t9390aubqCU4AySFqC1YCOUrFHNf2DtuscuX7Ls6MFJn5oqnIKuNracPa1w4IrJ+RN2/Fthv/2UQfUwnzYGeLiE95fS+7iLTR/+7a+/8doenzuOEnsj91SLQKnJjuNRLtqW8M8QmR6GqM69unVJ21Hr/U+8dujguU7f88bt+WO3uDd/5L5rGJmZxnIlGFXKm9PLkO7exzekL3f3Pv4RJL2PVfUZ4A3SHeJE5GA2jtBW0/90RX+9kQdUi0Cp1WpAG51kyJiOjhm/W7DowK1U9xj43QNTpe0t3emF+wpHdN6an7DnHN11DzZORNarUWV85kp6NE8nuQS6Ou1lPASYTtL/+A7gU+nk61PAywCqukxEZqSTtFNIJmV7+jNwfnq8l9i0N/KAGmaEgs2fZINq29eXr3z+k6tWVzRXokp+NSNeeKwQLZucP377GYWx++UZXA+XMaXYrZg3qepWPX6/iGRCt/vPS4GP9/GZduDkzRyv9+btU3t8bwObeVpfVUcNVKuPhwPHq+qMfl67rdJzFKne/7Wqey35/DO3LGh9x7u68mXdhu3SQfNm6bvn3JE/dujd+SP3W8VWY33XmDE7hC7ANx8jlF8AvR/k+tdrqnqJh3MUY9sancf0ptr5wTVrH//B0uXHDCphF0BVVi9ghxem5A9ff2v+uD1e1t1HUeS/2g2i4eb8KlnYdiTJk7079Vrktg1Vms0fgAVKAENV51zXurj90PUbBpx4VaWwli1efLxwwOLJ+eO3n144cL8uhmS1j04tWKD0MIzkuZ0hbDprvAr4WCVFlaklwDmb2gEbNjx6w8LFB49U3Wzv6C4dtPBF3eO1O/PHDL4rP36fFWyzP7B/DcvMsqGjLrpvyzcum7h24LfWh0oWtk0j6Rp4o6oWu9qvmrYa+C3GB1Fd/q1lK14+c/Wat23LqMq6RWw3+4H8YWsn54/f/QXd8z3ALgHKrBfb02MdSL3zMYcyXESuI7kF9q/jqeoJHo5dihE1Pl9T2j6fn3nL/NZdd87nj4C375f6SOGg/TsZUs+70tdaQ/1D6CNQbiN5OOl6oKInFStU9Go+UwbVjjNWr3ni28tWHFtQWfyC7j7jrvwx3JE/Zp9e+6Wa0oSYb6waH4HSparXeDhOpYaHLqBRDSnw2v+0Dnotv/ag4R/KH//qczp6DPDO0HU1CAuUXu4Vkf8E7iLZtwFIlgl7OHYpGm5/zqzoEnb64S66HbwKvMpWUOv/bxtXYXgBJoauwhsfgRKnX7/W4zWl9itXG2ZiK3OEbWq13LnpDN7QUA2/fOzYlpXHwteELsCYMoScd/Su4t7GIjJSRL6V3ulBRMaIyGmVl1YyG6GYetQVugCffDRL/y3QwcZ+OPOAH3o4bqksUEw9agtdgE8+AmW0ql5B2k4jfcoxxCW3BYqpN3mK3AmtXvgIlI5070kFEJHR9LjbU0MWKKbeLHWxs0nZXr5LsinL7iJyEzAeOMfDcUu1OsA5janEotAF+ObjLs9DIjKTZKs4Ab7koXdIOeYHOKcxlWi4QPFxyQPwLpIVf8OAY0Xko56OW4rXA5zTmEo0XKD42LHtBuBA4Hmg+3pQgTsrPXaJLFBMvbFA6cMRqhp8fwsXu8VRLlpDgz29aRpaa+gCfPNxyfOEiAQPlNScgd9iTGbMDl2Abz5GKDmSUGkluV0sgKpqiD4prwNRgPMaUw4XugDffATKDcAnSf7HCX1P3eZRTL1Y4WL3VugifPMRKHNV9R4Px/HhxdAFGFOkhhudgJ9AeVFE/gDcy6b7odT6Lg+U2OXMmICeC11ANfgIlBEkQdKzS1mI28YAsxi4d6sxWdCQIxRRbayNzqJc9BBJ93hjsuxIF7uGG1FX0ujr66p6hYj8gj62X1TVCyqqrHxPYIFism0D8GzoIqqhkkueF9Kv//BRiEdPhC7AmAHMcLFrD11ENVTS6Ove9LfrVHWThugickZFVVXmCZIRk22DarLqwdAFVIuPlbLfKPK1mnCxW8nG0ZMxWfRQ6AKqpZI5lFOAU4F3icjPe3xrG8Lvk/kg1j/XZNMS4OnQRVRLJSOUBSTzJ+uBf/b4dQ/wgcpLq8i9A7/FmCAedrFrrFurPQw4QhGRPMk98yEklxKxqq5T1WeBZ0XkD6raOcAxrgeuUtXZInKxql7S43uPq+pR/Xy8HNOBlcC2no9rTKUa9nIHihuhtKvqOFUdS7K7/fm9vn+4iDwkIi+LyOsiMkdENnmmRlXPVdXuJysv7vU932GCi10XcL/v4xpTIaWBJ2Sh9EueR4G9AETkKyIyC3iE5KG8o4EJwCvAOhGZJSIfT987VUQOFZHLgBEi8ky6/ywisib9eouInNp9IhG5UUROF5HBIvIjEXlKRJ4Tkc8VWevtJf7djKm2GS52Db1VadGBIiJDgFMAJyKHAJ8G3kfyTMLRJNtAHg68qapj0xHNn3seQ1UvYuOI5+xep5gMdAfQMOBEklHGZ4E2VT0MOAw4T0SK6VY4Bdu42mTLTaELqLZiAmWEiDxDMgE7F/gNSYDcpaprgb+QNCv6JEmfkVPT0cUxqlpKE6MpwAkiMpwkuKanPX5OBj6V1vB3YAdgzEAHc7Fbj03OmuzoBG4b8F11rpjbxu2qOq7nCyLSc9HY+4BdgdOAg0gufw4D9hKRB1X1+8UUoqrrRWQqyR2ijwM3d58O+KKqPlDMcXr5HXBWGZ8zxrcpLnYN1dSrL+XeNp4OfFhERpIEyRqSEDgbOElVDwB+DBzcx2c7RWToZo47meRS6higO0AeAD7f/RkR2VtEtiyyzgeBV4t8rzHV9JvQBdRCWYGiqjOBG4EnSS6F1gCXkGy/+KyIzAW+Sd89jq8DnuuelO3lQeBY4GFV7Uhfu55k782Z6STwtRS5IC+93/+rIv9axlRLK01y17Hi7QtEZApJw/Rvqup708nbp1U1E3u7RrloW5ImYCND12Ka1uUudheFLqIWfDzLs6Oq3kq6n6yqdpFMzmZC+mxPw8+um8zqBH4Zuoha8REoa0VkBzY2Sz+C5K5PljTN/6Emc37vYjcvdBG14iNQvkLy/M5oEZlBcmflix6O642L3XPAY6HrME2nAFweuoha8hEoo0nWjRxFckfmFfzsVevblaELME3nDhe7l0MXUUs+AuXbqroK2I5k68XrgGs8HNcrF7s/ktyVMqZWLg1dQK35CJTuCdiJwK9V9W5gmIfjVsPFA7/FGC8ecLFr2H1PNsdHoMwXkWuBM4H706XzPo7rnYvdX0geFTCm2i4Z+C2Nx8cP/pkkcyf/pqorge2Br3k4brUE257SNI27Xeymhy4ihIbry1OMKBfdAXw0dB2mIa0H9nexmxO6kBAyeWlSA98iQ4vvTEO5slnDBJo0UFzsXsCe8TH+vUWTzp10a8pASV0MvBm6CNNQvuZity50ESE1baC42K0Bit1O0piBTHWxuyV0EaE1baAAuNg9QPKogDGV2EDGHjcJpakDJfVlYFHoIkxd+4aL3azQRWRB0weKi91y7F8XU74HgJ+GLiIrmnIdSl+iXHQ7cHroOkxdWQIc6GLXGrqQrGj6EUoP5wJNu37AlOWzFiabskBJpTu7nUnSHdGYgVzjYmdtWnqxQOnBxe4fJJO0xvTneeDC0EVkkc2h9CHKRTeQtPMwprflwOEudq+FLiSLbITSt89jmzGZt+sEPmZhsnkWKH1wsdtA8jTygtC1mEz5oovdX0MXkWUWKJvhYjefpK9yw7ePNEW53MXu2tBFZJ0FSj9c7J4n2YB7dehaTFA3YRtzFcUmZYsQ5aLjgCnAFoFLMbX3EHCai50tJyiCjVCK4GI3lWSNSlfgUkxt/Rn4oIVJ8SxQipQuYjqHtEOiaXj3Ah92sVsfupB6YoFSAhe7m4DPYCOVRncncHp6t8+UwOZQyhDloonArcDI0LUY724Fznaxs380ymCBUqYoF70P+BOwY+hajDc3AbGLnW1gXia75CmTi93fgfHAG4FLMX78EPikhUllbIRSoSgX7UxyS3lc6FpMWdYB57jY3Ra6kEZgI5QKpfthTADuCV2LKdlcYLyFiT82QvEoykVfAS4DhoauxQzoMZI7OYtDF9JILFA8SydrbwH2DF2L2azrSB70swVrnlmgVEGUi7YDfgt8KHQtZhOLgfNd7O4KXUijskCpoigX/TdwBXYJlAV3koTJktCFNDILlCqLclEEXA8cHrqWJrWC5PLmptCFNAO7y1NlLnYOOBL4ErAmcDnNZgow1sKkdmyEUkNRLtoN+AnwsdC1NLh5wEUWJLVngRJAlIveD/wC2Dd0LQ2mHfgxcJmL3brQxTQjC5RAolw0lGQ7hG9it5grVSBpev8dF7u3QhfTzCxQAkuD5dPAxViwlONekmblz4cuxFigZEYaLJ8hCZY9ApeTdR0kTwZf5WI3K3QxZiMLlIyJctEwkkuhLwAHhq0mc5YB1wBXW0/hbLJAybB0Gf95wCeALQOXE9JLwE+BnItde+hizOZZoNSBKBdtDZxFEi6HBC6nVhYDtwGTgRkudvYfah2wQKkzUS46iGQdy2k03iXRCpIl8pOBv9pmR/XHAqWORblod5JgOQ04HhgRtqKyvApMBe4GHnCx6wxbjqmEBUqDiHLRCOBE4CTgCJId5IYFLapvL5MEyDRgqoud9Y9uIBYoDSrKRcOBg4FDScJlHHAAMLxGJSgwB5gFPA88C0x3sVtYo/ObACxQmkiUi4YAuwK7A7v18XUXknarQ0lGN8OAIb0Os4FkrqPnr5Xp1zdJLmFeBV6zOzLNxwLF9CvKRcLGgOmyTnqmPxYoxhhvbD8UY4w3FijGGG8sUIwx3ligGGO8sUAxxnhjgWKM8cYCxRjjjQWKMcYbCxRjjDcWKMYYbyxQjDHeWKAYY7yxQDHGeGOBYozxxgLFGOONBYoxxhsLFGOMNxYoxhhvLFCMMd5YoBhjvLFAMcZ4Y4FijPHGAsUY440FijHGGwsUY4w3FijGGG8sUIwx3vx/fJ+haNZ5BwYAAAAASUVORK5CYII=\n",
      "text/plain": [
       "<Figure size 432x288 with 1 Axes>"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "def sentiment_labeler(score):\n",
    "    if(score==5 or score==4):\n",
    "        return \"Positive\"\n",
    "    elif (score==3):\n",
    "        return \"Neutral\"\n",
    "    else:\n",
    "        return \"Negative\"\n",
    "\n",
    "data[\"sentiment_label\"]=data[\"reviews.rating\"].apply(sentiment_labeler)\n",
    "data[\"sentiment_label\"].value_counts().sort_values().plot.pie()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 159,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>reviews.rating</th>\n",
       "      <th>reviews.text</th>\n",
       "      <th>reviews.title</th>\n",
       "      <th>sentiment_label</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>0</th>\n",
       "      <td>NaN</td>\n",
       "      <td>I order 3 of them and one of the item is bad q...</td>\n",
       "      <td>... 3 of them and one of the item is bad quali...</td>\n",
       "      <td>Neutral</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1</th>\n",
       "      <td>NaN</td>\n",
       "      <td>Bulk is always the less expensive way to go fo...</td>\n",
       "      <td>... always the less expensive way to go for pr...</td>\n",
       "      <td>Positive</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2</th>\n",
       "      <td>NaN</td>\n",
       "      <td>Well they are not Duracell but for the price i...</td>\n",
       "      <td>... are not Duracell but for the price i am ha...</td>\n",
       "      <td>Positive</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3</th>\n",
       "      <td>NaN</td>\n",
       "      <td>Seem to work as well as name brand batteries a...</td>\n",
       "      <td>... as well as name brand batteries at a much ...</td>\n",
       "      <td>Positive</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>4</th>\n",
       "      <td>NaN</td>\n",
       "      <td>These batteries are very long lasting the pric...</td>\n",
       "      <td>... batteries are very long lasting the price ...</td>\n",
       "      <td>Positive</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "   reviews.rating                                       reviews.text  \\\n",
       "0             NaN  I order 3 of them and one of the item is bad q...   \n",
       "1             NaN  Bulk is always the less expensive way to go fo...   \n",
       "2             NaN  Well they are not Duracell but for the price i...   \n",
       "3             NaN  Seem to work as well as name brand batteries a...   \n",
       "4             NaN  These batteries are very long lasting the pric...   \n",
       "\n",
       "                                       reviews.title sentiment_label  \n",
       "0  ... 3 of them and one of the item is bad quali...         Neutral  \n",
       "1  ... always the less expensive way to go for pr...        Positive  \n",
       "2  ... are not Duracell but for the price i am ha...        Positive  \n",
       "3  ... as well as name brand batteries at a much ...        Positive  \n",
       "4  ... batteries are very long lasting the price ...        Positive  "
      ]
     },
     "execution_count": 159,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "#predicting Sentiment Label\n",
    "data['reviews.rating'] = data['reviews.rating'].map(lambda x: int(2) if x =='positive' else int(0) if x =='negative' else int(1) if x == 'Neutral' else np.nan)\n",
    "data.head()\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.7.6"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 4
}
